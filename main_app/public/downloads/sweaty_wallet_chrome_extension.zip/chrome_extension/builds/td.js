(() => {
  // scripts/utils/docReady.js
  function docReady(fn) {
    if (document.readyState === "complete" || document.readyState === "interactive") {
      setTimeout(fn, 1);
    } else {
      document.addEventListener("DOMContentLoaded", fn);
    }
  }
  var docReady_default = docReady;

  // scripts/tabs/td/pull_accounts.js
  function getAccounType(productGroupType) {
    if (productGroupType === "BANKING") return "deposit_account";
    if (productGroupType === "CREDIT") return "credit_card";
    if (productGroupType === "LOAN_MORTGAGE") return "mortgage";
    return "unknown_account";
  }
  function extract_accounts_from_profile_groups(profile_groups) {
    const accounts = [];
    profile_groups.forEach((profile_group) => {
      const product_groups = profile_group.productGroups;
      product_groups.forEach((product_group) => {
        const type = getAccounType(product_group.productGroupType);
        const td_accounts = product_group.accounts || [];
        td_accounts.forEach((account) => {
          accounts.push({
            type,
            external_id: account.accountKey,
            encrypted_external_id: account.accountIdentifier,
            account_name: account.accountDesc,
            nick_name: null,
            balance: account.balanceAmt.amount,
            is_active: true,
            currency: account.balanceAmt.currencyCd
          });
        });
      });
    });
    return accounts;
  }
  function makeRequest() {
    return new Promise((resolve) => {
      function reqListener() {
        const response = JSON.parse(this.responseText);
        const profile_groups = response.financialSummaries.personalSummary.profileGroups;
        resolve(extract_accounts_from_profile_groups(profile_groups));
      }
      const req = new XMLHttpRequest();
      req.open("GET", "https://easyweb.td.com/ms/uainq/v1/accounts/summary");
      req.setRequestHeader("TraceabilityID", crypto.randomUUID());
      req.setRequestHeader("Messageid", crypto.randomUUID());
      req.setRequestHeader("Originating-App-Name", "RWUI-uf-fs");
      req.setRequestHeader("Originating-App-Version-Num", "1.5.34");
      req.setRequestHeader("TimeStamp", (/* @__PURE__ */ new Date()).getTime());
      req.setRequestHeader("Originating-Channel-Name", "EWP");
      req.setRequestHeader("Accept-Secondary-Language", "fr_CA");
      req.addEventListener("load", reqListener);
      req.send();
    });
  }
  function pullAccounts(msg) {
    return makeRequest().then((accounts) => {
      return {
        name: msg.name,
        params: accounts
      };
    });
  }

  // scripts/tabs/td/pull_deposit_account.js
  function toDate() {
    const today = /* @__PURE__ */ new Date();
    return today.toISOString().slice(0, 10);
  }
  function fromDate() {
    const today = /* @__PURE__ */ new Date();
    const monthsAgo = 3;
    today.setMonth(today.getMonth() - monthsAgo);
    return today.toISOString().slice(0, 10);
  }
  function mapTransaction(account_id, transaction) {
    const is_debit = !!transaction.withdrawalAmt;
    return {
      external_id: transaction.transactionId,
      secondary_external_id: "",
      external_account_id: account_id,
      description: transaction.description,
      date: transaction.date,
      type: is_debit ? "debit" : "credit",
      amount: is_debit ? transaction.withdrawalAmt : transaction.depositAmt,
      external_object: transaction
    };
  }
  function makeRequest2(msg) {
    return new Promise((resolve) => {
      function reqListener() {
        const response = JSON.parse(this.responseText);
        const mapTransactionFunc = mapTransaction.bind(null, msg.params.accountId);
        const transactions = response.transactionList.transactions.map(mapTransactionFunc);
        resolve(transactions);
      }
      const req = new XMLHttpRequest();
      req.open("POST", `https://easyweb.td.com/ms/uainq/v1/accounts/${msg.params.identifier}/transactions`);
      req.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      req.setRequestHeader("TraceabilityID", crypto.randomUUID());
      req.setRequestHeader("Messageid", crypto.randomUUID());
      req.setRequestHeader("Originating-App-Name", "RWUI-uf-fs");
      req.setRequestHeader("Originating-App-Version-Num", "1.5.34");
      req.setRequestHeader("TimeStamp", (/* @__PURE__ */ new Date()).getTime());
      req.setRequestHeader("Originating-Channel-Name", "EWP");
      req.setRequestHeader("Accept-Secondary-Language", "fr_CA");
      req.addEventListener("load", reqListener);
      req.send(
        JSON.stringify({
          description: "chq/sav_initLoad",
          endDt: toDate(),
          startDt: fromDate()
        })
      );
    });
  }
  function parse_description(text) {
    if (text.indexOf("\nView more") !== -1) {
      return text.split("\nView more")[0].replace("View more", "").trim();
    }
    return text;
  }
  function parse_transaction(row, external_account_id) {
    const tds = row.querySelectorAll("td");
    if (tds.length === 0) return null;
    const date = tds[0] && tds[0].innerText.trim();
    const description = tds[1] && tds[1].innerText.trim();
    const debit = tds[2] && tds[2].innerText.trim();
    const credit = tds[3] && tds[3].innerText.trim();
    const balance = tds[4] && tds[4].innerText.trim();
    if (!date || !debit && !credit && !balance) return null;
    const type = debit ? "debit" : "credit";
    const amount = debit || credit;
    const parsed_description = parse_description(description);
    const secondary_external_id = `${date}-${parsed_description}-${type}-${amount}-${balance}`.replace(/ /g, "");
    return {
      external_id: secondary_external_id.replace(/ /g, ""),
      secondary_external_id,
      external_account_id,
      description: parsed_description,
      date,
      type,
      amount,
      external_object: { balance }
    };
  }
  function parse_transactions(transaction_rows, external_account_id) {
    const transactions = [];
    for (let i = 0; i < transaction_rows.length; i++) {
      const row = transaction_rows[i];
      const transaction = parse_transaction(row, external_account_id);
      if (transaction) transactions.push(transaction);
    }
    return transactions;
  }
  function pullDepositAccountFromApi(msg) {
    return makeRequest2(msg).then((res) => {
      return {
        name: msg.name,
        params: res
      };
    });
  }
  function pullDepositAccountFromPage(msg) {
    return new Promise((resolve) => {
      const transaction_rows = document.querySelectorAll("#tabcontent1 #content1 table tr");
      const transactions = parse_transactions(transaction_rows, msg.params.identifier);
      resolve({
        name: msg.name,
        params: transactions
      });
    });
  }

  // scripts/tabs/td/pull_credit_card_account.js
  function mapTransaction2(account_id, transaction) {
    const is_debit = !!transaction.debit;
    const date = transaction.postedDt;
    const type = is_debit ? "debit" : "credit";
    const amount = is_debit ? transaction.debit.amt : transaction.credit.amt;
    const description = transaction.transactionDesc;
    const balance = transaction.balance.amt;
    const secondary_external_id = `${date}-${description}-${type}-${amount}-${balance}`.replace(/ /g, "");
    return {
      external_id: transaction.transactionId,
      secondary_external_id,
      external_account_id: account_id,
      description,
      date,
      type,
      amount,
      external_object: transaction
    };
  }
  function creditCardTransactionPromise(accountId, cycle) {
    return new Promise((resolve) => {
      function reqCreditCardListener() {
        const response = JSON.parse(this.responseText);
        const mapTransactionFunc = mapTransaction2.bind(null, accountId);
        const transactions = response.transactions.posted.map(mapTransactionFunc);
        resolve(transactions);
      }
      const req = new XMLHttpRequest();
      req.open("GET", `https://easyweb.td.com/waw/api/account/creditcard/transactions?accountKey=${accountId}&cycleId=${cycle}`);
      req.addEventListener("load", reqCreditCardListener);
      req.send();
    });
  }
  function pullCreditCardAccount(msg) {
    const promises = [
      creditCardTransactionPromise(msg.params.identifier, 0),
      creditCardTransactionPromise(msg.params.identifier, 1),
      creditCardTransactionPromise(msg.params.identifier, 2)
    ];
    return Promise.all(promises).then((res) => {
      return {
        name: msg.name,
        params: res.flat()
      };
    });
  }

  // scripts/tabs/td/td.js
  var TD_NEW_FRONTEND_URL = "https://easyweb.td.com/ui";
  var TD_OLD_FRONTEND_URL = "https://easyweb.td.com/waw";
  var TD_CREDIT_CARD_URL = "https://easyweb.td.com/waw/webui";
  var TD_DEPOSIT_ACC_URL = "https://easyweb.td.com/ui/ew/da";
  function onTabLoad() {
    const port = chrome.runtime.connect({ name: "td_port" });
    const current_url = window.location.href;
    const is_new_frontend = current_url.startsWith(TD_NEW_FRONTEND_URL);
    const is_old_frontend = current_url.startsWith(TD_OLD_FRONTEND_URL);
    const is_credit_card = current_url.startsWith(TD_CREDIT_CARD_URL);
    const is_deposite_acc_url = current_url.startsWith(TD_DEPOSIT_ACC_URL);
    if (is_credit_card) {
      port.postMessage({ name: "redirect_to_credit_card_url" });
    } else if (is_deposite_acc_url || is_old_frontend) {
      port.postMessage({ name: "redirect_to_deposit_acc_url", params: { url: current_url } });
    } else if (is_new_frontend) {
      port.postMessage({ name: "redirect_to_new_frontend_url" });
    } else if (is_old_frontend) {
      port.postMessage({ name: "redirect_to_old_frontend_url" });
    }
    port.onMessage.addListener((msg) => {
      if (msg.name === "ping") {
        port.postMessage({ name: msg.name, params: { received: true } });
      } else if (msg.name === "redirect_to_new_frontend_url") {
        window.location.href = msg.params.url;
      } else if (msg.name === "redirect_to_old_frontend_url") {
        window.location.href = msg.params.url;
      } else if (msg.name === "redirect_to_credit_card_url") {
        window.location.href = msg.params.url;
      } else if (msg.name === "redirect_to_deposit_acc_url") {
        window.location.href = msg.params.url;
      } else if (msg.name === "pull_accounts") {
        pullAccounts(msg).then((res) => port.postMessage(res));
      } else if (msg.name === "pull_transactions_credit_card") {
        pullCreditCardAccount(msg).then((res) => {
          port.postMessage(res);
        });
      } else if (msg.name === "pull_transactions_deposit_account") {
        if (is_deposite_acc_url) {
          pullDepositAccountFromApi(msg).then((res) => {
            port.postMessage(res);
          });
        } else {
          pullDepositAccountFromPage(msg).then((res) => {
            port.postMessage(res);
          });
        }
      }
    });
  }
  docReady_default(onTabLoad);
})();
