import MessageController from "./message_controller.js"

// eslint-disable-next-line no-new
new MessageController()
